'use strict'

//Callback hell example.  Not good!
layer1((err, value1) => {
    if (err) {
        // handle error for layer1
    }
    layer2(value1, (err, value2) => {
        if (err) {
            // handle error for layer2
        }
        layer3(value2, (err, value3) => {
            if (err) {
                // handle error for layer3
            }
            layer4(value3, (err, value4) => {
                if (err) {
                    // handle error for layer4
                }
                layer5(value4, (err, value5) => {
                    if (err) {
                        // handle error for layer5
                    }
                    layer6(value5, (err, value6) => {
                        if (err) {
                            // handle error for layer6
                        }
                        // finally, do something with value6
                        console.log(value6);
                    });
                });
            });
        });
    });
});
