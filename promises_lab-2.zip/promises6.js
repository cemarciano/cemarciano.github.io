

function getUser(username, password) {

    return new Promise((resolve, reject) => {

        const request = new XMLHttpRequest();

        request.open("GET", "./json/userList.json");
        request.send()

        request.addEventListener("readystatechange", () => {
            //console.log(request, request.readyState)
            if (request.readyState === 4 && request.status === 200) {
                // Request successful
                userList = JSON.parse(request.responseText)
                for (let i=0; i < userList.length; i++) {
                    if (userList[i]["username"] === username && userList[i]["password"] === password){
                        resolve(userList[i])
                    }
                }
            } else if (request.readyState === 4) {
                // Request failed
                reject("Could not fetch user")
            }
        })

    })

}


function getWallet(walletId) {

    return new Promise((resolve, reject) => {

        const request = new XMLHttpRequest();

        request.open("GET", "./json/walletList.json");
        request.send()

        request.addEventListener("readystatechange", () => {
            //console.log(request, request.readyState)
            if (request.readyState === 4 && request.status === 200) {
                // Request successful
                walletList = JSON.parse(request.responseText)
                for (let i=0; i < walletList.length; i++) {
                    if (walletList[i]["walletId"] === walletId){
                        resolve(walletList[i])
                    }
                }
            } else if (request.readyState === 4) {
                // Request failed
                reject("Could not fetch wallet")
            }
        })

    })

}

let input_username = "bravo"
let input_password = "abc"

getUser(input_username, input_password).then(user => {
    console.log(user)
    return getWallet(user["walletId"])
}).then(userWallet => {
    console.log("User " + input_username + " has " + userWallet["ETH"] + " ETH")
}).catch(error => {
    console.log(error)
});
