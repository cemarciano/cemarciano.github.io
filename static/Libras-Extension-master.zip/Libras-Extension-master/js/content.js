var librasWidth;
var librasHeight;


function resetLibrasAspect(){
	librasWidth = 0.18*window.innerHeight + 0.07*window.innerWidth;
	librasHeight = 0.18*window.innerHeight + 0.07*window.innerWidth;
}

$(document).ready(function(){
	// Calculates Libras window aspect ratio:
	resetLibrasAspect();

	// Creates libras window and appends it to DOM:
	var div = $("<div></div>").attr("id", "librasWindow");
	$("body").append(div);

	////////////////////

	var container, controls;
	var camera, scene, renderer, model, mixer;
	var clock = new THREE.Clock();

	init();
	animate();

	function init() {

		// Container for three.js to be inserted into:
		container = document.createElement( 'div' );
		document.getElementById("librasWindow").appendChild( container );

		// Creates a camera:
		camera = new THREE.PerspectiveCamera( 25, librasWidth / librasHeight, 0.01, 100 );
		// This line is necessary so the camera won't spawn inside the object:
		camera.position.z = 2;

		// Uncomment this line to allow for controls. Also uncomment line in animate():
		//controls = new THREE.TrackballControls( camera );

		// Creates a scene:
		scene = new THREE.Scene();
		// Adds a hemisphere light:
		scene.add( new THREE.HemisphereLight() );

		// Creates a directional light:
		var directionalLight = new THREE.DirectionalLight( 0xffeedd );
		directionalLight.position.set( 0, 0, 2 );
		scene.add( directionalLight );

		// Loads model:
		var loader = new THREE.GLTFLoader();
		loader.load( chrome.extension.getURL("/models/gltf/boxing.gltf"),
			// Function to be called when done loading:
			function ( gltf ) {
				// Adds the model to the scene:
				scene.add( gltf.scene );
				// Saves a pointer to the model:
				model = gltf.scene;
				// Sets the model position in the scene (obtained empirically):
				model.position.set(-0.15,-1.4,0);
				// Animations:
				mixer = new THREE.AnimationMixer(model);
                mixer.clipAction(gltf.animations[0]).play();
			},
			// Function to be called while loading:
			undefined,
			// Function to be called if loading goes wrong:
			function ( error ) {
				console.error( error );
			}
		);

		// Creates a renderer:
		renderer = new THREE.WebGLRenderer();
		// Controls resolution (0.5 is very blurry, 3 is very nitid):
		renderer.setPixelRatio( 2 );
		// Controls size of window:
		renderer.setSize( librasWidth, librasHeight );
		container.appendChild( renderer.domElement );

		// Resizes three.js box whenever the user resizes his browser:
		window.addEventListener( 'resize', resize, false );

	}

	// Function to be called whenever the user resizes his browser:
	function resize() {

		// Calculates Libras window aspect ratio:
		resetLibrasAspect();

		// Updates camera:
		camera.aspect = 1;
		camera.updateProjectionMatrix();

		// Updates renderer:
		renderer.setSize( librasWidth, librasHeight );

	}

	function animate() {

		var delta = clock.getDelta();
        if (mixer != null) {
            mixer.update(delta);
        };

		// Renders scene:
		renderer.render( scene, camera );

		// Uncomment this line to allow for controls. Also uncomment line in init():
		//controls.update();

		// Requests another frame whenever the browser is ready to display it:
		requestAnimationFrame( animate );

	}

});
