$(document).ready(function(){
	// Create input fields to control model positioning:
	var form = $("<form></form>");
	var inputPos = [$("<input>").attr("id", "posX").attr("type", "text"),
				$("<input>").attr("id", "posY").attr("type", "text"),
				$("<input>").attr("id", "posZ").attr("type", "text")
			];
	var inputRot = [$("<input>").attr("id", "rotX").attr("type", "text"),
				$("<input>").attr("id", "rotY").attr("type", "text"),
				$("<input>").attr("id", "rotZ").attr("type", "text")
			];

	form.append(inputPos);
	form.append(inputRot);
	$("body").append(form);
});
